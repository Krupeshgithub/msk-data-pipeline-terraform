"""Terraform can't directly support create the MSK topic with the custom configuration."""
import boto3
import os
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)


def lambda_handler(event, context):
    """Create the topic into the MSK Cluster.
    :event: The event data from the Terraform.
    :context: The context data from the Terraform.
    """
    cluster_arn = os.environ.get("CLUSTER_ARN")
    topic_name = event["topic_name"]

    msk_client = boto3.client("kafka")
    # Created msk topic with the custom configuration.
    msk_client.create_topic(
        ClusterArn=cluster_arn,
        TopicName=topic_name,
        NumberOfPartitions=2
    )

    logger.info(f"MSK topic {topic_name} created successfully.")

    # Fetch the object from the s3 bucket and push the data into the MSK topic.
    s3_client = boto3.client("s3")
    bucket_name = os.environ.get("BUCKET_NAME")
    object_key = event["object_key"]

    # Read object from the s3 bucket.
    try:
        response = s3_client.get_object(
            Bucket=bucket_name,
            Key=object_key
        )
        object_data = response["Body"].read().decode("utf-8")

        for itr in object_data:
            response = msk_client.put_record(
                StreamName=topic_name,
                Data=itr
            )
        return {"message": "Data pushed successfully."}
    except Exception as e:
        logger.error(f"Error: {e}")
        return {"message": "Data not pushed into the MSK topic."}
